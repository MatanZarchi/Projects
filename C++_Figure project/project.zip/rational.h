#pragma once
#include <iostream>
#include "polynomial.h"
using namespace std;

class Rational
{
public:
	Rational();
	Rational(Polynomial, Polynomial);
	~Rational();
	void print()const;
	friend ostream& operator<<(ostream &, const Rational);
	Polynomial getNom()const;
	Polynomial getDenom()const;
private:
	Polynomial nom;
	Polynomial denom;
};