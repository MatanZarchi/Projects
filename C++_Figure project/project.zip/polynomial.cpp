#include <iostream>
#include "polynomial.h"
#include "rational.h"
#define _CRT_SECURE_NO_WARNING
using namespace std;

int Polynomial::maxDegree = 0;


Polynomial::Polynomial(double* other, int degree) :degree(degree)
{
	arr = new double[degree + 1];
	for (int i = 0; i < degree + 1; i++)
		this->arr[i] = other[i];
	if (degree > maxDegree)
		maxDegree = degree;
}
Polynomial::Polynomial(int degree) :degree(degree)
{
	arr = new double[degree + 1];
	for (int i = 0; i < degree + 1; i++)
		arr[i] = 0;
}
Polynomial::Polynomial(const Polynomial &other) :degree(other.degree)
{
	arr = new double[degree + 1];
	for (int i = 0; i < degree + 1; i++)
		this->arr[i] = other.arr[i];
}


Polynomial::~Polynomial()
{
	delete arr;
}
void Polynomial::setCoeff(int degree, double num)
{
	if (degree > maxDegree)
		maxDegree = degree;
	this->arr[degree] = num;
}
int Polynomial::getMaxDegree()
{
	return maxDegree;
}
int Polynomial::getDegree(bool val) const
{
	if (val == false)
		return this->degree;
	if (val == true)
	{
		for (int i = this->degree; i >= 0; i--)
		{
			if (this->arr[i] != 0)
				return i + 1;
		}
	}
	return 0;
}
void Polynomial::print() const
{
	cout << "polynomial = ";
	int index = getDegree(true);
	if (index == 0)
		cout << 0;
	else
	{
		cout << arr[0];
		for (int i = 1; i < index; i++)
		{
			if (arr[i] >= 0)
				cout << '+';
			cout << arr[i] << 'X' << '^' << i;
		}
	}
	cout << endl;
}
ostream &operator<<(ostream &os, const Polynomial& p)
{
	p.print();
	return os;
}
