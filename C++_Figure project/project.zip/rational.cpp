#include <iostream>
#include "rational.h"
#include "polynomial.h"
#define _CRT_SECURE_NO_WARNING
using namespace std;

Rational::Rational() :denom(), nom()
{
	this->denom.setCoeff(0, 1.0);
}
Rational::Rational(Polynomial p1, Polynomial p2) : nom(p1), denom(p2)
{

}
Rational::~Rational()
{

}
void Rational::print() const
{
	this->nom.print();
	cout << "--------------------------" << endl;
	this->denom.print();
}

ostream &operator<<(ostream &os, const Rational r)
{
	r.print();
	return os;
}

Polynomial Rational::getDenom()const
{
	return denom;
}
Polynomial Rational::getNom()const
{
	return nom;
}
