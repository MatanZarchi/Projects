#include "Zoo.h"



int main()
{
	//while (1)
	//{
	//	try
	//	{
	//		Mammal Mammal1;
	//		Mammal1.print();
	//		Mammal1.makeNoise();
	//		break;
	//	}
	//	catch (const char* error)
	//	{
	//		cout << error << endl;
	//	}
	//}
	
	//Insect Insect1;
	//Insect1.print();
	//Insect1.maKeNoise();

	//Fly f;
	//Horse h;
	//Lion l;
	//f.print();
	//f.makeNoise();
	//h.print();
	//h.makeNoise();
	//l.print();
	//l.makeNoise();

	Zoo myZoo("Kef-Hay");
	myZoo.MENU();


	
	

}	